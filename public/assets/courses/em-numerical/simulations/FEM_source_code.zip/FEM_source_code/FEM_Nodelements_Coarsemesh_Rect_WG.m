
c = 299792458;
freq = 1e10;
lambda = c/freq;

% Generation of the Node Connectivity Table:
% ==========================================

N_elements = 18;
n_1st_local_node = [1 2 2 2 3 3 5 5 6 6 7 8 9 9 10 10 11 12];
%simply creating this 18-element row vector with these elements
n_2nd_local_node = [2 6 3 7 4 8 6 10 7 11 8 12 10 14 11 15 12 16];	%contains global node indices of all local
%node #2 of all "N_element" elements. For instance, the 4th element's 2nd localnode is globalnode#7
n_3rd_local_node = [5 5 7 6 8 7 10 9 11 10 11 11 14 13 15 14 15 15];	%for instance, the 9th element's 3rd local
%node is globalnode#11

mu = ones(1,N_elements);	%create a row vector of 18 ones
eps = ones(1,N_elements);	%as above
ko = 2*pi/lambda;

%create 3-by-N_elements matrix n, whose kth row contains the globalnode indices of all kth localnodes of all
%"N_element" elements (where N_element = 18)
%idea is to perceive 'triangle connectivity table' as 3x18 matrix n, by tilting head and see
%this table from the side. The 3 columns of this table is now the 3 rows of matrix n while the 18 rows of
%the table is now the 18 columns of matrix n. i.e. simply means the transpose of connectivity table
for e = 1:N_elements
    n(1,e) = n_1st_local_node(e);
    n(2,e) = n_2nd_local_node(e);
    n(3,e) = n_3rd_local_node(e);
end

non_cond = [6 7 10 11]; %those global nodes that are not on boundary of rectangular waveuide, to be used for TM modes

%%% Define dimensions along x and y - USER DEFINED %%%
a = 0.1;
b = 0.05;
factor_x = a/1.5;
factor_y = b/0.75;

% Nodes locations table:
% ======================
xnodes = [0 0.5 1 1.5 0 0.5 1 1.5 0 0.5 1 1.5 0 0.5 1 1.5]*factor_x;
%whose nth element is the x-coordinate value of the nth global node
ynodes = [0 0 0 0 0.25 0.25 0.25 0.25 0.5 0.5 0.5 0.5 0.75 0.75 0.75 0.75]*factor_y;
%whose nth element is the y-coordinate value of the nth global node


% Initialization process:
% ======================
A = zeros(N_elements);	%creates an N_elements by N_elements square matrix A of zeros
Kdel = zeros(N_elements);
K = zeros(N_elements);
Kedel = zeros(3);	%creates 3 by 3 square matrix of zeros

% Loop through all elements:
% ==========================

for e = 1:N_elements
    
    % E_z (or TM) polarization:
    pe = 1/mu((e));
    qe = eps((e));
    
    % H_z (or TE) polarization:
    pe = 1/eps((e));
    qe = mu((e));
    
    %Coordinates of the Element nodes:
    for i = 1:3
        x(i) = xnodes(n(i,e));	%recall that n is a 3-by-N_elements matrix, whose kth row contains the globalnode
        %indices of all kth localnodes of all "N_element" elements
        %for a certain 'e'loopvalue (element index), corresponding to the eth column of matrix n, and for a certain
        %'i'loopvalue (localnode index), the quantity n(i,e) is the globalnode index, (say globindex) of the ith
        %localnode of the eth element; and the (globindex)th element of rowvector xnode, (whose nth element is the
        %x-coordinate value of the nth global node), is placed in the ith element of vector x
        %hence for a certain 'e'loopvalue (element index) pertaining to a certain eth element, the pth element of
        %3-element (row)vector x is the x-coordinate of this eth element's pth localnode, for p = 1, 2, 3
        y(i) = ynodes(n(i,e));	%as above, this creates 3-element (row)vector y, whose pth element (for p=1,2,3) is
        %the y-coordinate of the eth element's (the current 'e'loopvalue) pth localnode
    end
    
    % Compute the Element matrix entriesl:
    % ====================================
    Area = 0.5*abs((x(2)-x(1))*(y(3)-y(1))-(x(3)-x(1))*(y(2)-y(1)));	%from Area = 0.5*[R12] X [R13]
    
    %A(n(i,e),n(i,j))=0;
    %Kdel(n(i,e),n(i,j))=0;
    %K(n(i,e),n(i,j))=0;
    
    %cyclic coding
    
    for i = 1:3
        
        i1 = 0;
        
        if i == 3
            i1 = 3;
        end
        
        ip1 = (i+1) - i1;		%ip1 is 'i plus 1'
        i2 = 0;
        if ip1 == 3		%meaning i == 2
            i2 = 3;
        end
        ip2 = ip1 + 1 - i2;	%only when i == 2 and ip1 == 3 will i2 be non-zero (will be 3), and ip2 will be 3+1-3=1
        bi = y(ip1) - y(ip2);	%y is 3-element (row)vector whose pth element (for p=1,2,3) is the y-coordinate of
        %the current eth element's pth localnode (current 'e'loopvalue)
        ci = x(ip2) - x(ip1);
        
        for j = 1:3
            j1 = 0;
            if j == 3
                j1 = 3;
            end
            jp1 = (j+1) - j1;		%jp1 is 'j plus 1'
            j2 = 0;
            
            if jp1 == 3		%meaning j == 2
                j2 = 3;
            end
            jp2 = jp1 + 1 - j2;	%only when j == 2 and jp1 == 3 will j2 be non-zero (will be 3), and jp2 will be 3+1-3=1
            bj = y(jp1) - y(jp2);	%y is 3-element (row)vector whose pth element (for p=1,2,3) is the y-coordinate
            %of the current eth element's pth localnode (current 'e'loopvalue)
            cj = x(jp2) - x(jp1);
            
            Ae(i,j) = -(pe*(bi*bj + ci*cj))/(4*Area);	%use Eq. (52) Slide#65 of CEM class notes, where the del operator
            %had already been executed, accounting for the products bi*bj and ci*cj (the former due to differentiation
            %with respect to x, while the latter due to differentiation with respect to y)
            
            Kedel(i,j) = -Ae(i,j);	%negate Ae(i,j) just above, so that the minus sign in front of it is removed
            
            if i == j
                Ke(i,j) = qe*(Area/6);
                Ae(i,j) = Ae(i,j) + (ko^2)*qe*(Area/6);	%from Eq. (59a) Slide#70 of class notes
            else
                Ke(i,j) = qe*(Area/12);
                Ae(i,j) = Ae(i,j) + (ko^2)*qe*(Area/12);	%from Eq. (59a) Slide#70 of class notes
            end
            
            %Note that in the above steps, the matrix Ae is broken down to 2 parts: Kedel and Ke
            
            % Assemble the Element matrices into the Global FEM system:
            % =========================================================
            %for the following 3 steps, use the next coming step as example, by studying matrix assembled on
            %Pg 137 of class slides
            %recall that A, Kdel and K are all initially assigned zeros-matrix of size N_elements by N_elements
            %hence, these matrices are built up, by accumulating contributions from each iteration (loop)
            %idea is to perceive 'triangle connectivity table' of assignment as 3x18 matrix n, by tilting head and see
            %this table from the side. The 3 columns of this table is now the 3 rows of matrix n while the 18 rows of
            %the table is now the 18 columns of matrix n. i.e. simply means the transpose of connectivity table
            %Thus, when we are in the 'e'th loopvalue (element index), we are in the 'e'th row of connectivity table
            A(n(i,e),n(j,e)) = A(n(i,e),n(j,e)) + Ae(i,j);
            %For instance, consider the (2,6)th element of matrix equation on Pg 137 of slides, which is
            %A(i=1,j=2,e=2)+A(i=1,j=3,e=4). Thus, for each element index 'e'loopvalue, ('e'th row of connectivity
            %table), the row(of connectivity table)='e'loopvalue containing both the digits '2' & '6' are
            %detected
            %i.e. when e=2(2nd row of connectivity table), i=1 & j=2, then n(i,e)=n(1,2)=2 & n(j,e)=n(2,2)=6 [use transposed connectivity table, which is matrix n]
            %then the Ae(i,j)=Ae(1,2) for this current 'e'loopvalue(element index e=2) is added to whatever is already
            %in the (2,6)th position of matrix A
            %also when e=4(4th row of connectivity table), i=1 & j=3, then n(i,e)=n(1,4)=2 & n(j,e)=n(3,4)=6 [use transposed connectivity table, which is matrix n]
            %then the Ae(i,j)=Ae(1,3) for this current 'e'loopvalue(element index e=4) is added to whatever is already
            %in the (2,6)th position of matrix A
            %For instance, consider the (10,10)th element of matrix equation on Pg 137 of slides, which is A33(e=7)+...
            %...+A22(e=8)+A33(e=10)+A22(e=13)+A11(e=15)+A11(e=16), the same above is performed
            
            Kdel(n(i,e),n(j,e)) = Kdel(n(i,e),n(j,e)) + Kedel(i,j);	%apply same concept as above
            
            K(n(i,e),n(j,e)) = K(n(i,e),n(j,e)) + Ke(i,j);	%apply same concept as above
            
        end	%end the j loop
        
    end	%end the i loop
    
end	%end the element index e loop

K_TE = K;
Kdel_TE = Kdel;
A_TE = A;

K_TM = K(non_cond, non_cond);
Kdel_TM = Kdel(non_cond, non_cond);
A_TM = A(non_cond, non_cond);

eig_squares_TE = eig(Kdel_TE, K_TE);
% [eigvector_TE,eig_squares_TE] = eig(Kdel_TE, K_TE);
%[V,D] = EIG(A,B) produces a diagonal matrix D of generalized eigenvalues and a full matrix V whose columns are the
%corresponding eigenvectors so that A*V = B*V*D
%E = EIG(A,B) is a vector containing the generalized eigenvalues of square matrices A and B
%so in present case, eig_squares_TE is a vector containing the eigenvalues of square matrices Kdel_TE and K_TE
eig_values_indices_TE = find(eig_squares_TE > 0);
%I = FIND(X) returns the indices of the vector X that are non-zero
%For example, I = FIND(A>100), returns the indices of A where A is greater than 100
%so for present case, eig_values_indices_TE is a vector whose elements are the indices of the vector eig_squares_TE
%that are >=0
eig_values_TE = sqrt(eig_squares_TE(eig_values_indices_TE));
eig_values_TE = sort(eig_values_TE);
%   For vectors, SORT(X) sorts the elements of X in ascending order
%   For matrices, SORT(X) sorts each column of X in ascending order
%for present case, the vector eig_values_TE's elements are sorted in ascending order


eig_squares_TM = eig(Kdel_TM, K_TM);
% [eigvector_TM,eig_squares_TM] = eig(Kdel_TM, K_TM);
eig_values_indices_TM = find(eig_squares_TM > 0);
eig_values_TM = sqrt(eig_squares_TM(eig_values_indices_TM));
eig_values_TM = sort(eig_values_TM);



%for waveguide dimensions: width=a & height=b, theoretical formula for cutoff wavenumber Kcmn of the (mn)th mode is
%Kcmn = sqrt((m*pi/a)^2 + (n*pi/b)^2)
%this cutoff wavenumber Kc is also known as the transverse phase constant
%%%%% theoretical cutoff frequency fcmn = (1/(2*sqrt(mew*eps)))*sqrt((m/a)^2 + (n/b)^2) %%%%%
mewo = pi*4e-7;
epso = 8.854187818e-12;
mewr = 1;   %relative permeability of material filling rectangular waveguide
epsr = 1;   %relative permittivity of material filling rectangular waveguide
mew = mewr*mewo;
eps = epsr * epso;
wavevel = 1/sqrt(mew*eps);

%%%%% theoretical cutoff wavenumber Kcmn = sqrt((m*pi/a)^2 + (n*pi/b)^2) %%%%%
count = 1;
for p = 0:20
    for q = 0:20
        KcpqTE(count) = sqrt((p*pi/a)^2 + (q*pi/b)^2);
        fcpqTE(count) = (1/(2*sqrt(mew*eps)))*sqrt((p/a)^2 + (q/b)^2);
        count = count + 1;
    end
end
nonzeroindices = find(KcpqTE);
nonzeroKcpqTE = KcpqTE(nonzeroindices);
sortnonzeroKcpqTE = sort(nonzeroKcpqTE);
vector = [1:15];
figure(1)
plot(vector, sortnonzeroKcpqTE(1:15), '*', vector, eig_values_TE(2:16), '+'); grid  %compares theoretical & simulated cutoff wavenumbers
xlabel('Index case')
ylabel('Cutoff wavenumber k_c = sqrt( (m*pi/a)^2 + (n*pi/b)^2 )')
title('For TE modes')
legend('theoretical','FEM-simulated')


count = 1;
for p = 1:20
    for q = 1:20
        KcpqTM(count) = sqrt((p*pi/a)^2 + (q*pi/b)^2);
        fcpqTM(count) = (1/(2*sqrt(mew*eps)))*sqrt((p/a)^2 + (q/b)^2);
        count = count + 1;
    end
end
nonzeroindices = find(KcpqTM);
nonzeroKcpqTM = KcpqTM(nonzeroindices);
sortnonzeroKcpqTM = sort(nonzeroKcpqTM);
vector = [1:4];
figure(2)
plot(vector, sortnonzeroKcpqTM(1:4), '*', vector, eig_values_TM(1:4), '+'); grid  %compares theoretical & simulated cutoff wavenumbers
xlabel('Index case')
ylabel('Cutoff wavenumber k_c = sqrt( (m*pi/a)^2 + (n*pi/b)^2 )')
title('For TM modes')
legend('theoretical','FEM-simulated')


nonzeroindices = find(fcpqTE);
nonzerofcpq = fcpqTE(nonzeroindices);
sortnonzerofcpqTE = sort(nonzerofcpq);

nonzeroindices = find(fcpqTM);
nonzerofcpq = fcpqTM(nonzeroindices);
sortnonzerofcpqTM = sort(nonzerofcpq);



%%%%% simulated cutoff frequency %%%%%
cutoffreqTE = (wavevel/(2*pi))*eig_values_TE;     %basic formula, with eig_values_TE being vector containing cutoff wavenumbers for various modes
cutoffreqTM = (wavevel/(2*pi))*eig_values_TM;     %basic formula, with eig_values_TE being vector containing cutoff wavenumbers for various modes

vector = [1:15];
figure(3)
plot(vector, sortnonzerofcpqTE(1:15), '*', vector, cutoffreqTE(2:16), '+'); grid  %compares theoretical & simulated cutoff frequencies
xlabel('Index case')
ylabel('Cutoff frequency')
title('For TE modes')
legend('theoretical','FEM-simulated')

vector = [1:4];
figure(4)
plot(vector, sortnonzerofcpqTM(1:4), '*', vector, cutoffreqTM(1:4), '+'); grid  %compares theoretical & simulated cutoff frequencies
xlabel('Index case')
ylabel('Cutoff frequency')
title('For TM modes')
legend('theoretical','FEM-simulated')
















